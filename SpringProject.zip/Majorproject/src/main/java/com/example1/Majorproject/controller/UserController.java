package com.example1.Majorproject.controller;


		import java.util.List;

		import org.springframework.beans.factory.annotation.Autowired;
		import org.springframework.http.HttpStatus;
		import org.springframework.http.ResponseEntity;
		import org.springframework.web.bind.annotation.DeleteMapping;
		import org.springframework.web.bind.annotation.GetMapping;
		import org.springframework.web.bind.annotation.PathVariable;
		import org.springframework.web.bind.annotation.PostMapping;
		import org.springframework.web.bind.annotation.PutMapping;
		import org.springframework.web.bind.annotation.RequestBody;
		import org.springframework.web.bind.annotation.RestController;

		import com.example1.Majorproject.entity.User;
		import com.example1.Majorproject.service.UserService;



		@RestController
		public class UserController {

			
			@Autowired
			UserService itservice;
			
			@PostMapping("/adduser")
			public User regItem(@RequestBody User it) {
				return itservice.addItem(it);
			}
			
			@GetMapping("/getuser")
			public List<User> getIt(){
				return itservice.getItem();
			}
			
			@DeleteMapping("/userdelete/{id}")
			public ResponseEntity<String> deleteUser(@PathVariable("id") Long id) {
			    if (itservice.existsById(id)) {
			        itservice.deleteItem(id);
			        return ResponseEntity.ok("User with ID " + id + " deleted successfully.");
			    } else {
			        return ResponseEntity.status(HttpStatus.NOT_FOUND)
			                             .body("User with ID " + id + " not found.");
			    }
			}


			
			@PutMapping("/updateuser")
			public ResponseEntity<?> updateIt(@RequestBody User item) {
			    if (itservice.existsById((long) item.getId())) 
			    {
			         User updatedItem = itservice.UpdateItem(item);
			        return ResponseEntity.ok(updatedItem);
			    } 
			    else 
			    {
			        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Item with ID " + item.getId() + " not found.");
			    }
			}
         }


