package com.example1.Majorproject.service;


		import java.util.List;

		import org.springframework.beans.factory.annotation.Autowired;
		import org.springframework.stereotype.Service;

		import com.example1.Majorproject.entity.User;
		import com.example1.Majorproject.repository.UserRepo;
		@Service
				public class UserService {
				
					
					@Autowired
					public UserRepo irepo;
					
					//adding data
					public User addItem(User it) {
						return irepo.save(it);
					}
					
					//getting data
					public List<User> getItem(){
						
						return irepo.findAll();
					}
					
					//deleting data
					public void deleteItem(long id) {
						irepo.deleteById(id);
					}
					
					//update data
					public 	User UpdateItem(User item) {
						long itemid = item.getId();
						User item1 = irepo.findById((long) itemid).get();
						item1.setId(item.getId());
						return irepo.save(item);
					}

					public boolean existsById(Long id) {
						return irepo.existsById(id);
					}
					}


