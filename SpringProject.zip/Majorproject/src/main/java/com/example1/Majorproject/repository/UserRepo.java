package com.example1.Majorproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example1.Majorproject.entity.User;
public interface UserRepo extends JpaRepository<User,Long>{
		
}


